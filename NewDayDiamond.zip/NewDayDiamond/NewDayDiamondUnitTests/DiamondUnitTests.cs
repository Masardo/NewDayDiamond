// Further Tests for extension:
// Introducing Mocking objects with interfaces (i.e. Moq or NSubstitute)
// More tests for each input value
// Testing Erroneous inputs
// Testing with different SpaceCharacters

using Microsoft.VisualStudio.TestTools.UnitTesting;
using NewDayDiamondTest;

namespace NewDayDiamondTests
{
    /// <summary>
    /// Diamonds Test Class
    /// </summary>
    [TestClass]
    public class DiamondTests
    {
        /// <summary>
        /// Just to show I know these exist if needed
        /// </summary>
        [TestInitialize]
        [TestCleanup]

        /// <summary>
        /// Test that inputting A returns a correct pattern
        /// </summary>
        [TestMethod]
        public void GenerateDiamond_With_A_Returns_CorrectPatternTest()
        {
            // Arrange
            var diamond = new Diamond('_');

            // Act
            var result = diamond.GenerateDiamond('A');

            // Assert
            var expected = "A\r\n";
            Assert.AreEqual(expected, result);
        }

        /// <summary>
        /// Test that inputting C returns a correct pattern
        /// </summary>
        [TestMethod]
        public void GenerateDiamond_With_C_Returns_Correct_Pattern_Test()
        {
            // Arrange
            var diamond = new Diamond('_');

            // Act
            var result = diamond.GenerateDiamond('C');

            // Assert
            var expected = "__A__\r\n" +
                           "_B_B_\r\n" +
                           "C___C\r\n" +
                           "_B_B_\r\n" +
                           "__A__\r\n";
            Assert.AreEqual(expected, result);
        }
    }
}