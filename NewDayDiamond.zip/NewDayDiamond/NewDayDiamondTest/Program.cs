﻿// Diamond Test for NewDay Application
// Generate a Diamond from https://github.com/davidwhitney/CodeDojos/tree/master/Diamond%20Kata
// Originally from TDD post: https://claysnow.co.uk/recycling-tests-in-tdd/

namespace NewDayDiamondTest
{
    /// <summary>
    /// Console Application
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Main Argument
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            char inputChar;

            do
            {
                do
                {
                    Console.WriteLine(Constants.DefaultIntroductionMessage);
                    Console.WriteLine(Constants.DefaultIntroductionQuitMessage);

                    string? input = Console.ReadLine();

                    if (input == Constants.DefaultQuitKeyword)
                    {
                        Environment.Exit(0);
                    }
                    if (string.IsNullOrEmpty(input))
                    {
                        Console.WriteLine($"{Constants.InvalidInputNoValue}{Environment.NewLine}");
                    }
                    else if (input.Length != 1)
                    {
                        Console.WriteLine($"{Constants.InvalidInputMoreThanOneCharacter}{Environment.NewLine}");
                    }
                    else if (!char.IsLetter(input[0]))
                    {
                        Console.WriteLine($"{Constants.InvalidInputNonUnicodeCharacter}{Environment.NewLine}");
                    }
                    else
                    {
                        inputChar = char.ToUpper(input[0]);
                        break;
                    }
                } while (true);

                Diamond diamond = new Diamond(Constants.DefaultSpaceCharacter);
                string diamondPattern = diamond.GenerateDiamond(inputChar);

                IDiamondPrinter printer = new ConsolePrinter();
                printer.Print(diamondPattern);

            } while (true);
        }
    }
}