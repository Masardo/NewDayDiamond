﻿using System.Text;


namespace NewDayDiamondTest
{
    /// <summary>
    /// Diamond class
    /// </summary>
    public class Diamond
    {

        #region Fields

        private readonly char _spaceCharacter;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="spaceCharacter"></param>
        public Diamond(char spaceCharacter)
        {
            _spaceCharacter = spaceCharacter;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Generate string in a diamond-representation
        /// </summary>
        /// <param name="c"></param>
        /// <returns></returns>
        public string GenerateDiamond(char c)
        {
            int n = c - 'A';
            StringBuilder sb = new StringBuilder();

            // Generate top half (including middle row)
            for (int i = 0; i <= n; i++)
            {
                sb.AppendLine(GenerateLine(n, i));
            }

            // Generate bottom half (excluding middle row)
            for (int i = n - 1; i >= 0; i--)
            {
                sb.AppendLine(GenerateLine(n, i));
            }

            return sb.ToString();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Generate line of diamond structure
        /// </summary>
        /// <param name="n"></param>
        /// <param name="i"></param>
        /// <returns></returns>
        private string GenerateLine(int n, int i)
        {
            StringBuilder sb = new StringBuilder();

            // Append spaces before the character
            for (int j = 0; j < n - i; j++)
            {
                sb.Append(_spaceCharacter);
            }

            // Append the character
            sb.Append((char)('A' + i));

            // Append spaces and middle character if not first row
            if (i > 0)
            {
                for (int j = 0; j < 2 * i - 1; j++)
                {
                    sb.Append(_spaceCharacter);
                }
                sb.Append((char)('A' + i));
            }

            // Append spaces after the character if underscore
            if (_spaceCharacter == '_')
            {
                for (int j = 0; j < n - i; j++)
                {
                    sb.Append(_spaceCharacter);
                }
            }

            return sb.ToString();
        }

        #endregion
    }
}