﻿namespace NewDayDiamondTest
{
    /// <summary>
    /// Class to handle printing Diamond to console
    /// </summary>
    internal class ConsolePrinter : IDiamondPrinter
    {
        /// <summary>
        /// Prints string to console
        /// </summary>
        /// <param name="diamond"></param>
        public void Print(string diamond)
        {
            Console.WriteLine(diamond);
        }
    }
}
