﻿// Generally include a Constants class in my C# applications to limit magic numbers and strings

namespace NewDayDiamondTest
{
    /// <summary>
    /// Constants class
    /// </summary>
    internal class Constants
    {
        public const char DefaultSpaceCharacter = '_';

        public const string DefaultQuitKeyword = "Quit";

        public const string DefaultIntroductionMessage = "Enter a character to generate a diamond pattern";

        public const string DefaultIntroductionQuitMessage = $"Type {DefaultQuitKeyword} to exit the program";

        public const string InvalidInputNoValue = "Invalid input: No value entered. Please enter a single character.";

        public const string InvalidInputMoreThanOneCharacter = "Invalid input: More than one character was entered. Please enter a single character.";

        public const string InvalidInputNonUnicodeCharacter = "Invalid input: Non-Unicode character entered. Please enter a Unicode character.";
    }
}
