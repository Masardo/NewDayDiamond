﻿namespace NewDayDiamondTest
{
    /// <summary>
    /// Interface to extend print functionality of the diamond pattern without modifying existing classes
    /// </summary>
    public interface IDiamondPrinter
    {
        void Print(string diamond);
    }
}
